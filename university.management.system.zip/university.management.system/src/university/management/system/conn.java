/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university.management.system;



import java.sql.*;

public class conn {
    Connection c;
    Statement s;
    ResultSet res;
public static void main(String args[]) throws SQLException 
{
    Connection c =  null;
    Statement s = null;
    ResultSet res = null;
    
    
    try
   {
        c = DriverManager.getConnection("jdbc:derby://localhost:1527/UMSP", "stuti","stuti3515");
        
        s = c.createStatement();
        
        res = s.executeQuery("select * from LOGIN");
    while(res.next())
    {
       System.out.println(res.getString("username")+ ","+ res.getString("password") );
   }
   c.close();
   }
    
   catch (Exception e)
   {
       System.out.println(e);
   }
      
    }
}


